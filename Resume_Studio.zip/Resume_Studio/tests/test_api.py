import os, tempfile, unittest, sys
from pathlib import Path
os.environ['RESUME_DB']=str(Path(tempfile.mkdtemp())/'test.db')
sys.path.insert(0,str(Path(__file__).parents[1]/'backend'))
from main import app, analyze, conn
from fastapi.testclient import TestClient
class StudioTests(unittest.TestCase):
 def test_word_boundaries_and_no_skills(self):
  r=analyze('JavaScript developer with projects and education','Java developer using Docker')
  self.assertNotIn('Java',r['matched']); self.assertEqual(r['score'],0)
  self.assertIsNone(analyze('Any text','Gardening and watering flowers')['score'])
 def test_account_isolation_and_file_validation(self):
  a=TestClient(app); b=TestClient(app)
  self.assertEqual(a.post('/api/evaluate',data={'job':'Python developer and FastAPI REST APIs'},files={'resume':('x.pdf',b'%PDF-fake')}).status_code,401)
  self.assertEqual(a.post('/api/auth/register',json={'name':'Alice','email':'alice@example.com','password':'GoodPassword123'}).status_code,200)
  self.assertEqual(b.post('/api/auth/register',json={'name':'Bob','email':'bob@example.com','password':'GoodPassword123'}).status_code,200)
  uid=a.get('/api/auth/me').json()['id']
  with conn() as c:c.execute('INSERT INTO reports VALUES(?,?,?,?,?)',('owned',uid,1,'test.pdf','{"id":"owned"}'))
  self.assertEqual(len(a.get('/api/reports').json()),1)
  self.assertEqual(b.get('/api/reports').json(),[])
  self.assertEqual(b.delete('/api/reports/owned').status_code,404)
  self.assertEqual(a.post('/api/evaluate',data={'job':'Python developer and FastAPI REST APIs'},files={'resume':('x.pdf',b'not pdf')}).status_code,400)
  self.assertEqual(a.post('/api/auth/logout').status_code,200)
  self.assertEqual(a.get('/api/auth/me').status_code,401)
 def test_cross_origin_mutations(self):
  c=TestClient(app)
  self.assertEqual(c.post('/api/auth/register',headers={'origin':'https://evil.example'},json={'name':'x','email':'x@example.com','password':'Password123'}).status_code,403)
if __name__=='__main__':unittest.main()
