# Resume Studio

A complete evolution of the uploaded Resume Evaluator bootcamp exercises. React frontend, FastAPI backend, persistent SQLite accounts and reports, and a transparent resume-to-job keyword matching engine.

## التشغيل السريع — Windows

1. ثبّتي Python 3.11 أو أحدث، مع تفعيل Add Python to PATH.
2. فكّي ضغط المشروع.
3. افتحي الطرفية داخل مجلد المشروع واكتبي:

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r backend/requirements.txt
python -m uvicorn main:app --app-dir backend --host 127.0.0.1 --port 8000
```

4. افتحي **http://127.0.0.1:8000** في المتصفح.

نسخة الواجهة المبنية موجودة في `frontend/dist`؛ لا تحتاجين Node لتشغيل النسخة المرفقة. اضغطي **Try an example** لتجربة تقرير جاهز، أو أنشئي حسابًا لرفع سيرتك وحفظ التقارير.

## macOS / Linux

```sh
python3 -m venv .venv
. .venv/bin/activate
pip install -r backend/requirements.txt
python -m uvicorn main:app --app-dir backend --host 127.0.0.1 --port 8000
```

## Frontend development

Node.js 20.19+ or 22.12+ is recommended for the tooling.

```sh
cd frontend
npm ci
npm run dev
```

Keep the FastAPI server running on port 8000. Vite proxies `/api` to FastAPI. After editing, run `npm run build` and restart the backend to serve the updated build.

## What works

- Registration and sign-in with Argon2 password hashes.
- HttpOnly, SameSite session cookies, server-side expiry, logout, and a basic in-process login attempt limit.
- PDF upload, drag and drop, size/page limits, encrypted/scanned PDF error handling.
- A curated skill vocabulary with case-insensitive, word-boundary matching.
- Evidence snippets, missing keywords, section checks, practical next steps.
- Account-owned saved reports, history, deletion, and plain-text export.
- Real sample analysis without registration.
- Responsive dark interface, animated document illustrations, progress states, accessible native dialog, keyboard focus states, reduced-motion support.
- FastAPI interactive API documentation at `/docs`.

## Honest scoring

This application does **not** claim to predict recruiter decisions or provide an employer's ATS score. The score is:

`recognized job skills explicitly mentioned in resume / recognized job skills × 100`

A job description with no supported vocabulary returns no score. The engine does not understand negation, proficiency, mandatory versus desirable skills, language fluency, eligibility, or experience duration. Arabic and unknown synonyms have limited support. Review focus is a human review reminder; it is not an AI prompt. There is no live LLM integration in this version and no API key is needed.

## Privacy and deployment

Original PDF bytes and full extracted resume text are not stored. Saved reports contain the filename, skill matches, short evidence excerpts, structural checks and suggestions, which may contain personal information. Accounts and reports are stored in `backend/studio.db`, created automatically. Delete reports from the interface. Do not commit this database.

For a public deployment, use HTTPS, set `COOKIE_SECURE=1`, configure `ALLOWED_ORIGINS` for your exact frontend origin, and provision a durable database location via `RESUME_DB`. Keep one backend process for the current in-memory login limiter, or replace it with shared rate limiting before scaling. This local portfolio release has no email verification, password recovery, OCR, or live AI analysis. Do not host it with real applicant data without completing production hardening and retention/access requirements.

## Configuration

| Variable | Purpose |
| --- | --- |
| `RESUME_DB` | SQLite path; default is `backend/studio.db` |
| `COOKIE_SECURE` | Set `1` behind HTTPS |
| `ALLOWED_ORIGINS` | Comma-separated permitted mutation origins; same origin always allowed; defaults to localhost Vite development origins |

## Validation

```sh
python -m unittest discover -s tests -v
cd frontend
npm run build
```

Tests cover cross-account report isolation, session logout, invalid upload rejection, cross-origin mutation rejection, empty recognized vocabulary and Java/JavaScript word boundaries. A real PDF upload and saved report retrieval were verified via the API. A browser QA script was prepared, but graphical browser validation could not run in the restricted execution environment; responsive behavior is implemented but needs visual verification on a local device.

## Project structure

```text
backend/main.py          API, accounts, SQLite, PDF reader, matching engine
backend/requirements.txt
frontend/src/main.jsx    React interface and interactions
frontend/src/styles.css  Theme, responsive layouts and motion
frontend/dist/           Ready-to-run production frontend
frontend/package-lock.json
sample-data/            Sample job description and resume text
tests/test_api.py        API validation
```

## Portfolio description

**Resume Studio — Resume-to-Job Matching Platform**

Built a React and FastAPI application that parses PDF resumes, compares explicit skills with job descriptions, and produces explainable match reports. Implemented Argon2 authentication, cookie-based sessions, SQLite persistence, account-isolated report history, export, input validation, and responsive interactive UI design.

Describe the project as a keyword matching platform, not AI agents or a production ATS. The sample content is illustrative and does not assert new experience on behalf of the project owner.
