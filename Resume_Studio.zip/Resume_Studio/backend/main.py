"""Resume Studio: local-first resume matching with persistent accounts and reports."""
import hashlib, io, json, os, re, secrets, sqlite3, time
from pathlib import Path
from fastapi import FastAPI, HTTPException, Request, Response, UploadFile, File, Form
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from argon2 import PasswordHasher
from pypdf import PdfReader

DB = os.getenv('RESUME_DB', str(Path(__file__).parent / 'studio.db'))
app = FastAPI(title='Resume Studio API', version='1.0.0')
ph = PasswordHasher()
SKILLS = {'Python':['python'], 'FastAPI':['fastapi'], 'React':['react','react.js','reactjs'], 'JavaScript':['javascript','js'], 'TypeScript':['typescript'], 'SQL':['sql'], 'MySQL':['mysql'], 'PostgreSQL':['postgresql','postgres'], 'SQLite':['sqlite'], 'REST APIs':['rest','restful','rest api'], 'Git':['git'], 'GitHub':['github'], 'Docker':['docker'], 'AWS':['aws','amazon web services'], 'Azure':['azure'], 'Firebase':['firebase','firestore'], 'HTML':['html'], 'CSS':['css'], 'Java':['java'], 'C++':['c++'], 'C#':['c#'], '.NET':['.net','dotnet'], 'Node.js':['node.js','nodejs'], 'Figma':['figma'], 'Jira':['jira'], 'Notion':['notion'], 'Machine Learning':['machine learning'], 'AI':['ai','artificial intelligence'], 'AI Agents':['ai agents','ai agent','agentic'], 'Documentation':['documentation','technical writing','documented'], 'Requirements':['requirements','user stories','acceptance criteria'], 'Testing':['testing','pytest','postman'], 'OAuth2':['oauth2','oauth'], 'JWT':['jwt'], 'RBAC':['rbac','role-based'], 'Communication':['communication'], 'Teamwork':['teamwork','collaboration','collaborative']}

def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
with conn() as c:
    c.executescript('CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE,name TEXT,password TEXT); CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id INTEGER,expires REAL); CREATE TABLE IF NOT EXISTS reports(id TEXT PRIMARY KEY,user_id INTEGER,created REAL,filename TEXT,data TEXT);')

@app.middleware('http')
async def security(request, call_next):
    if request.method not in ('GET','HEAD','OPTIONS'):
        origin=request.headers.get('origin')
        allowed={str(request.base_url).rstrip('/')} | set(filter(None,os.getenv('ALLOWED_ORIGINS','http://localhost:5173,http://127.0.0.1:5173').split(',')))
        if origin and origin.rstrip('/') not in allowed:
            return Response('Cross-origin requests are not allowed', status_code=403)
    response=await call_next(request)
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['Referrer-Policy']='same-origin'
    response.headers['Cache-Control']='no-store' if request.url.path.startswith('/api') else 'no-cache'
    return response

def user(request):
    token=request.cookies.get('studio_session','')
    with conn() as c:
        row=c.execute('SELECT users.id,users.email,users.name FROM sessions JOIN users ON users.id=sessions.user_id WHERE token=? AND expires>?',(hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
    if not row: raise HTTPException(401,'Please sign in to continue.')
    return dict(row)
class Credentials(BaseModel):
    email: str = Field(max_length=254)
    password: str = Field(min_length=8,max_length=128)
    name: str = Field(default='',max_length=80)

def signin(response,u):
    token=secrets.token_urlsafe(32)
    with conn() as c:
        c.execute('DELETE FROM sessions WHERE expires<?',(time.time(),))
        c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),u['id'],time.time()+86400))
    response.set_cookie('studio_session',token,httponly=True,samesite='strict',secure=os.getenv('COOKIE_SECURE')=='1',max_age=86400)
    return {k:u[k] for k in ('id','name','email')}
@app.post('/api/auth/register')
def register(data:Credentials,response:Response):
    email=data.email.strip().lower()
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email) or not data.name.strip(): raise HTTPException(400,'Enter a valid email and your name.')
    try:
        with conn() as c:
            cur=c.execute('INSERT INTO users(email,name,password) VALUES(?,?,?)',(email,data.name.strip(),ph.hash(data.password)))
            u={'id':cur.lastrowid,'email':email,'name':data.name.strip()}
    except sqlite3.IntegrityError: raise HTTPException(409,'This email is already registered.')
    return signin(response,u)
ATTEMPTS={}
@app.post('/api/auth/login')
def login(data:Credentials,request:Request,response:Response):
    key=(request.client.host if request.client else 'local',data.email.lower())
    recent=[t for t in ATTEMPTS.get(key,[]) if t>time.time()-300]
    if len(recent)>=5: raise HTTPException(429,'Too many attempts. Try again in five minutes.')
    with conn() as c: u=c.execute('SELECT * FROM users WHERE email=?',(data.email.strip().lower(),)).fetchone()
    try:
        if not u: raise ValueError()
        ph.verify(u['password'],data.password)
    except Exception:
        ATTEMPTS[key]=recent+[time.time()]; raise HTTPException(401,'Incorrect email or password.')
    ATTEMPTS.pop(key,None)
    return signin(response,u)
@app.get('/api/auth/me')
def me(request:Request): return user(request)
@app.post('/api/auth/logout')
def logout(request:Request,response:Response):
    with conn() as c: c.execute('DELETE FROM sessions WHERE token=?',(hashlib.sha256(request.cookies.get('studio_session','').encode()).hexdigest(),))
    response.delete_cookie('studio_session'); return {'ok':True}

def has(text,term): return re.search(r'(?<![\w])'+re.escape(term)+r'(?![\w])',text,re.I) is not None

def analyze(resume,job,focus=''):
    required=[skill for skill,aliases in SKILLS.items() if any(has(job,a) for a in aliases)]
    matched=[s for s in required if any(has(resume,a) for a in SKILLS[s])]
    missing=[s for s in required if s not in matched]
    score=round(len(matched)/len(required)*100) if required else None
    evidence=[]
    for skill in matched:
        line=next((line.strip() for line in resume.splitlines() if any(has(line,a) for a in SKILLS[skill])),skill)
        evidence.append({'skill':skill,'evidence':line[:240]})
    sections={name:bool(re.search(pattern,resume,re.I)) for name,pattern in {'Experience':r'experience|employment|internship|trainee','Education':r'education|bachelor|university|degree','Projects':r'projects?|portfolio','Skills':r'skills|technologies|technical','Contact':r'[\w.+-]+@[\w.-]+\.[a-z]{2,}'}.items()}
    tips=[]
    if missing: tips.append({'title':'Make relevant experience easier to find','body':'The resume does not explicitly mention '+', '.join(missing[:6])+'. Add specific evidence only for skills you genuinely have; treat the rest as learning goals.'})
    if not all(sections.values()): tips.append({'title':'Strengthen your structure','body':'Add clear headings or content for: '+', '.join(k for k,v in sections.items() if not v)+'.'})
    tips.append({'title':'Show outcomes, not just tools','body':'Explain the problem, your contribution, and a measurable result where you can substantiate it. Never invent numbers.'})
    if focus.strip(): tips.append({'title':'Your review focus','body':focus.strip()[:500]+' — review the evidence below against this priority. This keyword engine does not interpret custom AI instructions.'})
    tips.append({'title':'Check requirements beyond keywords','body':'Manually verify degree eligibility, location, experience, language proficiency, and work authorization. These are not included in the match score.'})
    return {'score':score,'matched':matched,'missing':missing,'required':required,'evidence':evidence,'sections':sections,'tips':tips,'word_count':len(resume.split()),'engine':'Explainable keyword matching','disclaimer':'Keyword coverage, not an ATS score or hiring prediction. Synonyms, context, proficiency, and mandatory requirements need human review.'}
class TextEvaluation(BaseModel):
    resume: str=Field(min_length=50,max_length=50000)
    job: str=Field(min_length=30,max_length=20000)
    focus: str=Field(default='',max_length=1000)
@app.post('/api/evaluate/text')
def evaluate_text(data:TextEvaluation): return analyze(data.resume,data.job,data.focus)
@app.post('/api/evaluate')
async def evaluate(request:Request,resume:UploadFile=File(...),job:str=Form(...),focus:str=Form('')):
    u=user(request)
    if not 30<=len(job.strip())<=20000 or len(focus)>1000: raise HTTPException(400,'Use a job description between 30 and 20,000 characters.')
    raw=await resume.read(5*1024*1024+1)
    if len(raw)>5*1024*1024: raise HTTPException(413,'PDF must be 5 MB or smaller.')
    if not raw.startswith(b'%PDF-'): raise HTTPException(400,'Upload a valid PDF file.')
    try:
        reader=PdfReader(io.BytesIO(raw))
        if reader.is_encrypted or len(reader.pages)>20: raise ValueError()
        text='\n'.join(page.extract_text() or '' for page in reader.pages)[:50000]
    except Exception: raise HTTPException(400,'Unable to read this PDF. Use an unencrypted PDF of 20 pages or fewer.')
    if len(text.strip())<50: raise HTTPException(400,'No readable text found. Scanned PDFs need OCR; export a text-based PDF instead.')
    result=analyze(text,job,focus); result['id']=secrets.token_hex(12); result['filename']=Path(resume.filename or 'resume.pdf').name[:180]; result['created']=time.time()
    with conn() as c: c.execute('INSERT INTO reports VALUES(?,?,?,?,?)',(result['id'],u['id'],result['created'],result['filename'],json.dumps(result)))
    return result
@app.get('/api/reports')
def reports(request:Request):
    u=user(request)
    with conn() as c: rows=c.execute('SELECT data FROM reports WHERE user_id=? ORDER BY created DESC LIMIT 100',(u['id'],)).fetchall()
    return [json.loads(r['data']) for r in rows]
@app.delete('/api/reports/{report_id}')
def delete(report_id:str,request:Request):
    u=user(request)
    with conn() as c:
        count=c.execute('DELETE FROM reports WHERE id=? AND user_id=?',(report_id,u['id'])).rowcount
    if not count: raise HTTPException(404,'Report not found.')
    return {'ok':True}
@app.get('/api/health')
def health(): return {'status':'ok'}
web=Path(__file__).parent.parent/'frontend'/'dist'
if web.exists(): app.mount('/',StaticFiles(directory=web,html=True),name='frontend')
